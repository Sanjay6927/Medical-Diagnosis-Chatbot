from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import pandas as pd
from sklearn import preprocessing
from sklearn.tree import DecisionTreeClassifier
import numpy as np
import csv
import re
import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)

app = Flask(__name__,template_folder='templates')
app.secret_key = 'your_secret_key'  # Needed for session management

MAX_SYMPTOMS = 5  # Maximum number of symptoms to ask about

def initialize():
    global training, cols, clf, le, description_list, severity_dict, precaution_dict, symptoms_dict, reduced_data

    training = pd.read_csv('Data/Training.csv')
    cols = training.columns[:-1]

    le = preprocessing.LabelEncoder()
    le.fit(training['prognosis'])

    clf = DecisionTreeClassifier()
    clf.fit(training[cols], le.transform(training['prognosis']))

    reduced_data = training.groupby(training['prognosis']).max()

    get_description()
    get_severity_dict()
    get_precaution_dict()
    symptoms_dict = {symptom: index for index, symptom in enumerate(cols)}

def get_description():
    global description_list
    description_list = {}
    with open('MasterData/symptom_Description.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            description_list[row[0]] = row[1]

def get_severity_dict():
    global severity_dict
    severity_dict = {}
    with open('MasterData/symptom_severity.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            if row:
                severity_dict[row[0]] = int(row[1])

def get_precaution_dict():
    global precaution_dict
    precaution_dict = {}
    with open('MasterData/symptom_precaution.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            precaution_dict[row[0]] = row[1:]

@app.route("/")
def index():
    session.clear()  # Clear session to start fresh
    return render_template("main.html")

@app.route("/get", methods=["POST"])
def chat():
    msg = request.form["msg"]
    response = handle_message(msg)
    return jsonify(response)

def handle_message(msg):
    if "name" not in session:
        session["name"] = msg
        session["symptoms"] = []
        session["symptom_count"] = 0
        return f"Hello {session['name']}, please enter your first symptom."

    if "days" not in session:
        try:
            session["days"] = int(msg)
            if session["days"] > 5:
                return {
                    "text": "You have been experiencing symptoms for more than 5 days. It is recommended to consult a doctor.",
                    "redirect": url_for('connect_with_doctor')
                }
            return f"Please describe your symptoms. Are you experiencing {cols[0]}? (yes/no)"
        except ValueError:
            return "Please enter a valid number of days."

    symptoms_exp = session["symptoms"]

    if session["symptom_count"] < MAX_SYMPTOMS:
        symptoms_exp.append(msg)
        session["symptoms"] = symptoms_exp
        session["symptom_count"] += 1

        if session["symptom_count"] < MAX_SYMPTOMS:
            return f"Are you experiencing {cols[session['symptom_count']]}? (yes/no)"
        else:
            return diagnose(symptoms_exp)
    else:
        return diagnose(symptoms_exp)

def diagnose(symptoms_exp):
    input_vector = np.zeros(len(cols))
    for i, response in enumerate(symptoms_exp):
        if response.lower() == 'yes':
            input_vector[i] = 1

    prediction = clf.predict([input_vector])[0]
    disease = le.inverse_transform([prediction])[0]

    response = f"You may have {disease}. {description_list.get(disease, '')}"
    response += " Take the following measures: "
    for precaution in precaution_dict.get(disease, []):
        response += f"{precaution}, "

    return response

@app.route("/session-data")
def session_data():
    return jsonify(dict(session))

@app.route("/connect-with-doctor")
def connect_with_doctor():
    return render_template("connect_with_doctor.html")

@app.route("/chatbot")
def chatbot():
    return render_template("chat.html")

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/register")
def register():
    return render_template("register.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@app.route("/contact")
def contact():
    return render_template("contact.html")

if __name__ == '__main__':
    initialize()
    app.run(debug=True)
